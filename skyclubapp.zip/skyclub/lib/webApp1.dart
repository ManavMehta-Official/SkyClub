import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

class skyClubMain extends StatefulWidget {
  const skyClubMain({super.key});

  @override
  State<skyClubMain> createState() => _skyClubMainState();
}

class _skyClubMainState extends State<skyClubMain> {
  double statusBarHeight = 0.0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          // Access the context here
          statusBarHeight = MediaQuery.of(context).padding.top;
          return Container(
            padding: EdgeInsets.only(top: statusBarHeight),
            child: Center(
              child: WebviewScaffold(url: "https://manavmehta-official.github.io/SkyClub/")
            ),
          );
        },
      ),
    );
  }
}
